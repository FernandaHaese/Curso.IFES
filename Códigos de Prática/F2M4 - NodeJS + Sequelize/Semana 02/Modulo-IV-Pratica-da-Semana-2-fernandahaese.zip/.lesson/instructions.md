# Instructions  
Olá!

Nessa atividade você vai colocar em prática o conteúdo abordado na 2ª semana do módulo.

ESSA ATIVIDADE  SERÁ DESENVOLVIDA NO REPL.IT E DEVERÁ SER POSTADA SOMENTE OS ARQUIVOS NESTA TAREFA EM ARQUIVO ZIP, CONFORME ORIENTAÇÕES ABAIXO:

Orientações:

_ Assista ao vídeo das aulas da semana.
_ Leia em paralelo o material das aulas.
_ Acesse o Replit.
_ Crie um controller e um model cliente.
_ O model cliente deve se chamar clienteModel.js e terá os seguintes campos:
  _ id_cliente int tipo auto incremento chave primary key,
  _ nome string, não nulo,
  _ endereco string, não nulo,
  _ telefone string não nulo,
  _ email string, não nulo.

_ O arquivo controller será chamado clienteController.js e terá as funções do CRUD.
_ Crie as rotas para as requisições GET, POST, PUT e DELETE do controller clienteController.
_ Salve o código no seu computador.
_ Compacte o arquivo.
_ Envie o link do repl.it e o arquivo aqui.

Pessoal a atividade é semelhante ao que fizemos durante as aulas da semana, basta realizar as alterações incluindo o novo model e controller.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Bons estudos e boa atividade!

Valor: 7 pontos.