//Dependências
const express = require("express");
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
const database = require("./db/db");
const Cliente = require("./model/clienteModel");
const clienteController = require("./controller/clienteController");
//Rotas
app.get("/",(req, res) =>{
return res.json({message: "Seja bem-vindo(a)"});
})
app.post("/Cadastrar",clienteController.ClienteCreate);
app.get("/Clientes/:id?",clienteController.ClienteListar);
app.put("/Clientes/:id",clienteController.ClienteUpdate);
app.delete("/Clientes/:id",clienteController.ClienteDelete);
//Sincronismo com DB
try {
database.sync().then(() => {
})
}
catch(erro) {
console.log("Houve uma falha ao sincronizar com o banco de dados. ", erro);
};
//Servidor
app.listen(3000);