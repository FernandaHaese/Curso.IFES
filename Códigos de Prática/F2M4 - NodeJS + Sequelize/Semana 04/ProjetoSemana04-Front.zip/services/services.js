const axios = require("axios");
module.exports = class Services{
//Verificar funcionário
static async FuncionarioLogin(req,res){
let valores = req.body;
const options = {
url: 'https://f2m4-semana-04-api-livraria.fernandahaese.repl.co/login',
method: 'POST',
data: valores
};
axios(options).then((funcionario) => {
if(funcionario != undefined){
return res.render('logado');
}})}
//Cadastrar funcionário
static async FuncionarioCreate(req,res){
let valores = req.body;
const options = {
url: 'https://f2m4-semana-04-api-livraria.fernandahaese.repl.co/add_funcionario',
method: 'POST',
data: valores
};
axios(options);
const mensagem = "Cadastro realizado com sucesso!";
res.render("mensagem",{mensagem});
}
//Cadastrar livro
static async LivroCreate(req,res){
let valores = req.body;
const options = {
url: 'https://f2m4-semana-04-api-livraria.fernandahaese.repl.co/add_livros',
method: 'POST',
data: valores
};
axios(options);
const mensagem = "Cadastro realizado com sucesso!";
res.render("mensagem",{mensagem});
}
//Listar Livros
static async LivroListar(req,res){
const options = {
url: 'https://f2m4-semana-04-api-livraria.fernandahaese.repl.co/livros',
method: 'GET',
data: {}
};
axios(options).then(response => {
console.log(response.data);
const livro =response.data
res.render("livros/listar",{livro});
});
}
}