//Dependências
const express = require("express");
const Services = require("../services/services");
const router = express.Router();
//Rotas
router.get("/", (req,res) => {
  res.render("layouts/home")});
router.post("/login",Services.FuncionarioLogin);
//Rotas Funcionários
router.get("/login",(req, res) =>{
res.render("funcionarios/login");})
router.post("/login", Services.FuncionarioLogin)
router.get("/funcionarios/Cadastrar",(req, res) =>{
res.render("funcionarios/cadastrar");})
router.post("/funcionarios/Cadastrar",Services.FuncionarioCreate);
//Rotas Livros
router.get("/livros/Cadastrar",(req, res) =>{
res.render("livros/cadastrar");})
router.post("/livros/Cadastrar",Services.LivroCreate);
router.get("/livros/listar",Services.LivroListar);
//Exportação
module.exports=router;