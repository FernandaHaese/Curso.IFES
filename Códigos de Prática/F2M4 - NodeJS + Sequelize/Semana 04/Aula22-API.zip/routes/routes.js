//Módulos
const express = require("express");
const router = express.Router();
//Controllers
const usuarioController = require("../controller/usuarioController");
const produtoController = require("../controller/produtoController");
///Requisições HTTP Principal
router.get("/",(req, res) =>{
return res.json({message: "Sistema de Varejo"});
})
///Requisições HTTP Usuario 
//POST - Cadastrar
router.post("/add_usuario", usuarioController.UsuarioCreate);
//GET - Listar
router.get("/usuarios/:id?", usuarioController.verificaJWT, usuarioController.UsuarioListar);
//PUT - Update
router.put("/usuarios/:id", usuarioController.UsuarioUpdate);
// Delete
router.delete("/usuarios/:id", usuarioController.UsuarioDelete);
//POST - Verificar Login
router.post("/login", usuarioController.UsuarioVerificaLogin);
///Requisições HTTP Produto
//POST - Cadastrar Produtos
router.post("/add_produtos", produtoController.produtoCreate);
//GET - Listar Produtos
router.get("/produtos/:id?", produtoController.ProdutoListar);
//Exportação
module.exports = router;