//Dependências
const Sequelize = require('sequelize');
//Banco de Dados
const sequelize = new Sequelize({
dialect: 'sqlite',
storage: './varejo.sqlite'
})
//Tratamento de erros + Autentificação
try {
sequelize.authenticate();
console.log("Banco de dados conectado com sucesso!");
}
catch (erro) {
console.log("Erro ao conectar ao banco",erro);
}
//Exportação
module.exports = sequelize;