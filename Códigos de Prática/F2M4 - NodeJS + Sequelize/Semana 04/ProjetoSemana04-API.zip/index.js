//Dependências
const express = require("express");
const app = express();
const database = require("./db/db");
const routes = require("./routes/routes");
//JWT
const jwt = require('jsonwebtoken');
//Models
const Usuario = require("./model/funcionarioModel");
//Codificação JSON
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
//Rotas
app.use("/",routes);
//Sincronismo com o banco
try {
database.sync().then(() => {
})
}
catch(erro) {
console.log("Houve uma falha ao sincronizar com o banco de dados. ", erro);
};
//Servidor
app.listen(3000);