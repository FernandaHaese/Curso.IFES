//Módulos
const express = require("express");
const router = express.Router();
//Controllers
const funcionarioController = require("../controller/funcionarioController");
const livroController = require("../controller/livroController");
///Requisições HTTP Principal
router.get("/",(req, res) =>{
return res.json({message: "Sistema da Livraria"});
})
///Requisições HTTP Funcionario
//POST - Cadastrar
router.post("/add_funcionario", funcionarioController.FuncionarioCreate);
//GET - Listar
router.get("/funcionarios/:id?", funcionarioController.verificaJWT, funcionarioController.FuncionarioListar);
//PUT - Update
router.put("/funcionarios/:id", funcionarioController.FuncionarioUpdate);
// Delete
router.delete("/funcionarios/:id", funcionarioController.FuncionarioDelete);
//POST - Verificar Login
router.post("/login", funcionarioController.FuncionarioVerificaLogin);
///Requisições HTTP Livro
//POST - Cadastrar Livros
router.post("/add_livros", livroController.LivroCreate);
//GET - Listar Livros
router.get("/livros/:id?", livroController.LivroListar);
//Exportação
module.exports = router;