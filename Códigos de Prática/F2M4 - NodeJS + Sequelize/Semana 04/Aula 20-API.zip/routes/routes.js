//Módulos
const express = require("express");
const router = express.Router();
//Controllers
const usuarioController = require("../controller/usuarioController");
///Requisições HTTP Principal
router.get("/",(req, res) =>{
return res.json({message: "Sistema de Varejo"});
})
///Requisições HTTP Usuario 
//POST - CADASTRAR
router.post("/add_usuario", usuarioController.UsuarioCreate);
//GET - LISTAR
router.get("/usuarios/:id?", usuarioController.verificaJWT, usuarioController.UsuarioListar);
//PUT - UPDATE
router.put("/usuarios/:id", usuarioController.UsuarioUpdate);
// DELETE
router.delete("/usuarios/:id", usuarioController.UsuarioDelete);
//POST - Verificar Login
router.post("/login", usuarioController.UsuarioVerificaLogin);
//Exportação
module.exports = router;