//Dependências
var express = require("express");
var router = express.Router();

//Lista das cidades
var cidades = ["Linhares", "Cachoeiro", "Serra"];

//Aula 01 & 02
router.get("/", function (req, res) {
  res.send("Seja bem vindo ao nosso sistema.");
});
router.post("/", function (req, res) {
  res.send("Inserir registro");
});
router.get("/clientes", function (req, res) {
  res.send("Lista de todos os clientes!");
});
router.get("/clientes/:nome/:sobrenome?", function (req, res) {
  res.send(
    "Seja bem vindo <h1>" +
      req.params.nome +
      " " +
      req.params.sobrenome +
      "</h1>"
  );
});

//Aula 03
router.get("/cidades/:id", (req, res) => {
  let id = req.params.id;
  return res.json([cidades[id]]);
});
router.get("/cidades", (req, res) => {
  res.render("form");
});
router.post("/cidades/cadastrar", (req, res) => {
  let nome = req.body.nome;
  cidades[cidades.length] = nome;
  return res.json([cidades[cidades.lenght - 1]]);
});

//Aula 04
router.get("/par", function (req, res) {
  let nome = req.query["nome"];
  if (nome) {
    res.send("<h1>" + nome + "</h1>");
  } else {
    res.send("Não foi localizado nenhum valor no navegador.");
  }
  res.send("Nome = " + req.query["nome"]);
});

//Exportar rota
module.exports = router;
