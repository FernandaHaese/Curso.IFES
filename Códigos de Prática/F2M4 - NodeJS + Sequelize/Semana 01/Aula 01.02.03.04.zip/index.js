//Dependências
const express = require("express");
const app = express();
const porta = 3000;
const hand = require("express-handlebars");
app.set('view engine', 'html');
app.engine("handlebars", hand.engine());
app.set("view engine", "handlebars");

//Rotas
var Route = require('./routes/Route');
app.use(express.urlencoded({ extended: true }))
app.use('/', Route);
//app.get("/clientes", function (req, res) {
//res.send("Lista de Clientes");
//});
//app.post("/clientes", function (req, res) {
//res.send('Inserir um cliente');
//});

//Servidor
app.listen(porta, () => {
console.log("Servidor conectado.");
});