//Dependências
const express = require('express');
const app = express();
//Rotas
app.get('/', (req, res)=>{
  return res.json({message:'Seja Bem-vindo(a).'})
})
//Servidor
app.listen(3000);