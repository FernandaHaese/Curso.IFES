//Dependências
var express = require("express");
var router = express.Router();

//Lista das estados
const estados = [];

//Rota Principal
router.get("/", function (req, res) {
  res.send("<h2>Seja bem-vindo(a) a nosso sistema.</h2>" + "Digite /estados na url para acessar o formulário.");
});

//Rota do estado
router.get("/estados/:id", (req, res) => {
  let id = req.params.id;
  return res.json([estados[id]]);
});
router.get("/estados", function (req, res) {
  res.render("form");
});
router.post("/estados/cadastrar", (req, res) => {
  let nome = req.body.nome;
  estados.push(nome)
  return res.json(estados);
});

//Exportar rota
module.exports = router;