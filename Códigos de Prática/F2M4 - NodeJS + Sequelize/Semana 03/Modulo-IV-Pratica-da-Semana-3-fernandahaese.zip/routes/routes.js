//Dependências
const express = require("express");
const Services = require("../services/services");
const router = express.Router();
//Rotas
router.get("/",(req, res) =>{
res.render("usuarios/home");
})
router.get("/usuarios/cadastrar",(req, res) =>{
res.render("usuarios/cadastrar");
})
router.post("/usuarios/Create",Services.UsuarioCreate);
router.get("/usuarios/listar",Services.UsuarioListar);
router.get("/usuarios/Atualizar/:id_usuario/:titulo/:descricao",(req, res) =>{
let usuarios = {
id_usuario : req.params.id_usuario,
titulo : req.params.titulo,
descricao : req.params.descricao
}
res.render("usuarios/update",{usuarios});
})
router.post("/usuarios/Update",Services.UsuarioUpdate);
router.post("/usuarios/Delete",Services.UsuarioDelete);
//Exportação
module.exports=router;