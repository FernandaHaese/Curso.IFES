//Dependências
const database = require('./db/db');
const routes = require("./routes/routes");
const express = require('express');
const app = express();
//Informação JSON
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
//Models
const Usuario = require("./model/usuarioModel");
const Tarefa = require("./model/tarefasModel");
//Sincronismo com o banco
try {
database.sync().then(() => {
})
}
catch(erro) {
console.log("Houve uma falha ao sincronizar com o banco de dados. ", erro);
};
//Rotas
app.use("/",routes);
//Servidor
app.listen(3000);

