//Dependências
const Sequelize = require('sequelize');
//Banco de dados
const sequelize = new Sequelize({
dialect: 'sqlite',
storage: './usuario.sqlite'
})
//Tratamento de erros + Autentificação do banco de dados
try {
sequelize.authenticate();
console.log("Banco de dados conectado com sucesso!");
}
catch (erro) {
console.log("Erro ao conectar ao banco",erro);
}
module.exports = sequelize;