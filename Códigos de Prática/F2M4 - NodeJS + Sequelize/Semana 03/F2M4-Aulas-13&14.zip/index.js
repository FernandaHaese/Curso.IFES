//Dependências
const express = require('express');
const app = express();
var cookie = require('cookie-parser');
app.use(cookieParser());
//Dados do usuário
let usuario = {
nome : "Carla",
idade : "18"
}
//Rotas
app.get('/', (req, res)=>{
res.send('Seja Bem Vindo(a).');
});
//Rota adicionando o cookie
app.get('/adicionarUsuario', (req, res)=>{
res.cookie("usuarioDados", usuario,{expire: 400000 + Date.now()});
res.send('Dados do usuário adicionado com sucesso!');
});
//Rota para visualizar os dados do cookie
app.get('/usuarios', (req, res)=>{
res.send(req.cookies.usuarioDados);
});
//Rota de Logout
app.get('/logout', (req, res)=>{
res.clearCookie('usuariosDados');
res.send('Usuário desconectado com sucesso!');
});
//Servidor
app.listen(3000);

