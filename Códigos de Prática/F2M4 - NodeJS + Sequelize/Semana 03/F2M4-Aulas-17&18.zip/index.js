//Dependências
const express = require("express");
const app = express();
const hand = require("express-handlebars");
const Services = require("./services/services");
const routes = require("./routes/routes");
//Configurar handlebars e JSON
app.engine("handlebars", hand.engine());
app.set("view engine", "handlebars");
app.use(express.urlencoded({extended: true,}));
app.use(express.json());
//Rotas
app.use("/", routes);
//Servidor
app.listen(3000);