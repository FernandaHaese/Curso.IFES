// Atividade 01 - Rodízio de Veículos
exports.RodizioVeiculos = function RodizioVeiculos () {
// Obtém a placa do veículo através da linha de comando
const prompt = require("prompt-sync")();
const placa = prompt("Digite a placa do seu veículo 'e.g AAA-0000': ");
// Obtém o dia da semana atual
const dataAtual = new Date();
const diaSemana = dataAtual.getDay();
// Define a restrição de circulação para cada dia da semana
const restricao = {
  1: [1, 2],
  2: [3, 4],
  3: [5, 6],
  4: [7, 8],
  5: [9, 0]
};
// Verifica se a placa do veículo está restrita de acordo com o dia da semana
const ultimoDigito = placa[placa.length - 1];
const podeCircular = restricao[diaSemana].indexOf(ultimoDigito) === -1;
// Imprimi o resultado na tela
if (podeCircular) {
  console.log("O veículo de placa " + placa + " pode circular hoje.");
} else {
  console.log("O veículo de placa " + placa + " não pode circular hoje.");
}
}

//Atividade 02 - Formatação da Data
exports.FormatarData = function FormatarData () {
const prompt = require("prompt-sync")();
// Importa o módulo 'moment' para manipulação de datas
const moment = require('moment');
// Obtém a data via linha de comando
const dataStr = prompt("Insira uma data no formato DD/MM/AAAA: ");
// Converte a data para o objeto 'Date' do JavaScript
const data = moment(dataStr, 'DD/MM/YYYY').toDate();
// Obtém o dia, mês e ano da data
const dia = data.getDate();
const mes = data.getMonth();
const ano = data.getFullYear();
// Define um array com os nomes dos meses
const nomesMeses = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
// Imprimi a data por extenso na tela
console.log(`${dia} de ${nomesMeses[mes]} de ${ano}`);
}

//Atividade 03 - Divisão
exports.Divisao = function Divisao () {
const prompt = require ("prompt-sync")();
//Obtém os números via linha de comando
let num1 = prompt("Digite o primeiro número: ");
let num2 = prompt("Digite o segundo número: ");
//Define a divisão dos números
let resultado = num1 / num2;
//Realiza o tratamento de exceções
try {
      if (num2 === '0') {
        throw new Error('Divisão por zero');
      }
      console.log(`Resultado da divisão é ${resultado}`);
    } catch (err) {
      console.error(err.message);
    } 
}

//Atividade 04 - Leitura de Dados
exports.LeituraDados = function LeituraDados () {
  //Leitura dos dados
  const fs = require('fs');
  var dados = fs.readFileSync('dados.json' ) 
  //Conversão para Array
  const arrayDados = JSON.parse(dados);
  //Imprimi na tela
  console.log(arrayDados);
}

