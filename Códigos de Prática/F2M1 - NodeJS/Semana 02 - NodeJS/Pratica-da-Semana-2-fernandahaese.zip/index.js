const funcoes = require ('./funcoes.js');

//Chamando as funções das Atividades
funcoes.RodizioVeiculos();
funcoes.FormatarData();
funcoes.Divisao();
funcoes.LeituraDados();