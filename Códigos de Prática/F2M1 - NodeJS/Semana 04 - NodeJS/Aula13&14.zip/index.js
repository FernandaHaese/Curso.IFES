//Requisições HTTP com a biblioteca Axios

//Importando a API
const axios = require('./api.js');

//Método GET para buscar dados
async function carregarEstados(){
  try{
    var response = await axios.api.get('/Estados')
    console.log(response.data);
  }catch(err){
    console.log(err);
  }
}
carregarEstados();

//Alterar dados
async function alterarDados(){
  try {
    var response = await axios.api.put('/Estados/ES', {nome: 'Espirito Santo'});
    console.log(response.data);
  } catch(err){
    console.log(err);
  }}
//alterarDados ();

//Incluir dados
async function incluirDados(){
  try {
    var response = await axios.api.post('/Estados', {
      id: 'BA',
      nome: 'Bahia'
    });
    console.log(response.data);
      }catch(err){
    console.log(err);
      }
}
//incluirDados();

//Deletar dados
function deletarDados(){
    axios.api.delete('/Estados/SP')
    .then (() => {
      console.log('Mensagem de Sucesso.')
    }) 
    .catch((err) => {
      console.log(err);
    });}
//deletarDados();