//Exportações
const prompt = require('prompt-sync')();
const fs = require('fs');
const axios = require('./api.js');

//Criando um servidor
const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('db.json');
server.use(router);
server.listen(3000);

//Função para realizar a escolha
async function Escolha() {
  let opcao = -1;
  console.log('Bem-vindo ao sistema de gerenciamento de tarefas.');
  while (opcao !== 0) {
        console.log('O que você deseja fazer?');
        console.log('\n', '1. Cadastrar uma nova tarefa', '\n', '2. Alterar uma tarefa', '\n', '3. Marcar tarefa como concluída', '\n', '4. Excluir uma tarefa', '\n', '5. Listar tarefas pendentes', '\n', '6. Listar tarefas concluídas', '\n', '0. Sair do Sistema', '\n');
        opcao = Number(prompt("Escolha sua opção: "));
      switch (opcao) {
      case 1:
        await cadastrarTarefa();
        break;
      case 2:
        await alterarTarefa();
        break;
      case 3:
        await marcarConcluida();
        break;
      case 4:
        await excluirTarefa();
        break;
      case 5:
        await listarTarefas('Pendente');
        break;
      case 6:
        await listarTarefas('Concluída');
        break;
      case 0:
        console.log('Saindo do sistema...');
        process.exit();
      default:
        console.log('Opção inválida, tente novamente!');
        break;
    } 
}
}

//Função 01 - Cadastrar uma nova tarefa
async function cadastrarTarefa(){
  try {
    var id  = prompt('Informe o ID da tarefa: ');
    var descricao = prompt('Informe a descrição da tarefa: ');
    var status = 'Pendente'
    var response = await axios.api.post('/tarefas', {
      "id": id,
      "descricao": descricao,
      "status": status
    });
    console.log("Tarefa cadastrada com sucesso.");
      }catch(err){
    console.log("Erro ao cadastrar a tarefa.");
      }
  ClearMenu();
}

//Função 02 - Alterar uma tarefa
async function alterarTarefa(){
  try {
    var id = prompt('Informe o ID da tarefa que deseja alterar: ');
    var response = await axios.api.get(`/tarefas/${id}`);
    const tarefa = response.data
    if (!tarefa) {
      console.log('\n Tarefa não encontrada. \n');
      return;}
    var descricao = prompt('Informe a nova descrição da tarefa: ');
    await axios.api.patch(`/tarefas/${id}`, {descricao});
    console.log("Tarefa alterada com sucesso.");
  }catch(err){
    console.log("Erro ao alterar a tarefa.");
  }
  ClearMenu();
}


//Função 03 - Tarefa concluída
async function marcarConcluida(){
  try {
    const id = prompt('Informe o ID da tarefa concluída: ');
    var response = await axios.api.get(`/tarefas/${id}`);
    const tarefa = response.data
    if (!tarefa) {
      console.log('\n Tarefa não encontrada. \n');
      return;}
    
    await axios.api.put(`/tarefas/${id}`, { ...tarefa, status: "Concluída" });
    console.log("Tarefa atualizada com sucesso.");
  } catch(err){
    console.log("Ocorreu um erro ao atualizar a tarefa.");
  }
  ClearMenu();
}

//Função 04 - Exluir uma tarefa
async function excluirTarefa(){
  try {
    const id = prompt('Informe o ID da tarefa que deseja excluir: ');
    var response = await axios.api.get(`/tarefas/${id}`);
    const tarefa = response.data
    if (!tarefa) {
      console.log('\n Tarefa não encontrada. \n');
      return;}
    
		await axios.api.delete(`/tarefas/${id}`); 
		console.log('\nA tarefa foi excluída com sucesso!\n');
	} catch (erro) {
		console.log('\nOcorreu um erro ao excluir a tarefa.\n', erro);
	}
  ClearMenu();
}

//Função 05 - Listar tarefas pendentes e concluídas
async function listarTarefas(status){
  try{
    var response = await axios.api.get('/tarefas')
    var tarefas = response.data.filter(tarefa => tarefa.status === status);
    if (tarefas.length === 0) {
			console.log('\nNão há tarefas a serem exibidas.\n');
		} else {
			console.table(tarefas);
		}} catch (erro) {
		console.log('\nOcorreu um erro ao listar as tarefas.\n');
}
  ClearMenu();
}

//Função para limpar o menu
function ClearMenu () {
  prompt("\nEnter para continuar...");
	console.clear();
}

//Chamada da função Escolha
Escolha();
