//Exportando os arquivos com todos os cálculos
exports.calculos = function calculos() {

//
const prompt = require('prompt-sync')();
const alunos = [];

//Recebendo os valores de nomes e notas
for (let i = 0; i < 10; i++) {

    let nome = prompt(`Digite o nome do ${i+1}º aluno(a): `);
    let nota = parseFloat(prompt(`Digite a nota do ${i+1}º aluno(a): `));
    const aluno = {
        nome: nome,
        nota: nota
    };
    alunos.push(aluno);
}
  
//Declarando valores
let maiorNota = alunos[0].nota;
let nomeMaiorNota = alunos[0].nome;
let menorNota = alunos[0].nota;
let nomeMenorNota = alunos[0].nome;
let somaNotas = alunos[0].nota;
let aprovados = alunos[0].nota >= 60 ? 1 : 0;

for (let i = 1; i < alunos.length; i++) {
    const aluno = alunos[i];
  //Cálculo para maior e menor notas
    if (aluno.nota > maiorNota) {
        maiorNota = aluno.nota;
        nomeMaiorNota = aluno.nome;
    }
    if (aluno.nota < menorNota) {
        menorNota = aluno.nota;
        nomeMenorNota = aluno.nome;
    }
  //Cálculo dos aprovados 
  somaNotas += aluno.nota;
    if (aluno.nota >= 60) {
        aprovados++;
    }
}
//Cálculos da média e dos reprovados
const media = somaNotas / alunos.length;
const reprovados = alunos.length - aprovados;

//Imprimindo os resultados no terminal
console.log(`A maior nota é ${maiorNota}, tirada por ${nomeMaiorNota}`);
console.log(`A menor nota é ${menorNota}, tirada por ${nomeMenorNota}`);
console.log(`A média das notas é ${media}`);
console.log(`O número de alunos aprovados é ${aprovados}`);
console.log(`O número de alunos reprovados é ${reprovados}`);
}