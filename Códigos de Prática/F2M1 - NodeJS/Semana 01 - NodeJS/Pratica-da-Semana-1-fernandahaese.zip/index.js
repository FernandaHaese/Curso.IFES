//Importando o arquivo com todos os cálculos
const arquivo = require('./arquivo.js');

//Chamando todas as funções de cálculos
const calculos = arquivo.calculos();
