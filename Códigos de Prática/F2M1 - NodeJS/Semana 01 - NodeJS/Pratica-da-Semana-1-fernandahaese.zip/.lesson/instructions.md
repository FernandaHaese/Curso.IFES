# Prática da semana

Faça um programa em JavaScript que receba, via terminal, o nome de 10 alunos e suas respectivas notas recebidas em um determinado curso. Por exemplo:

Nome do aluno: João da Silva  
Nota: 89  

Nome do aluno: José Maria  
Nota: 74

Com os nomes e as notas, calcule:

a) a maior nota e o nome do aluno que a tirou  
b) a menor nota e o nome do aluno que a tirou  
c) a média de todas as notas  
d) a quantidade de alunos aprovados (nota maior ou igual a 60)  
e) a quantidade de alunos reprovados (nota menor que 60)  

Você deve utilizar os conhecimentos adquiridos no módulo 3 no FIC 1, que tratou da introdução a linguagem JavaScript. Porém, todos as funções e cálculos do exercício devem estar em um arquivo separado do index.js e você deverá importá-lo para o seu arquivo principal para utilizar as funções.