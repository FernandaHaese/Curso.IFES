const prompt = require('prompt-sync')();
const fs = require('fs');

//Função assíncrona para cadastrar novos dados 
async function cadastrarCarro() {
  var placa = prompt('Informe a placa do carro: ');
  var nome = prompt('Informe o nome do carro: ');
  var montadora = prompt('Informe a montadora do carro: ');

  const carro = {
    Placa: placa,
    Nome: nome,
    Montadora: montadora,
  };

  try {
    const carros = await obterCarros()
    const dados = JSON.parse(carros).dados;
    await incluirCarros(dados, carro);
  } catch (err) {
    console.error('Erro ao cadastrar carro:', err);
  }
}

function incluirCarros(dados, carro) {
  dados.push(carro);
  var json = JSON.stringify({ dados: dados });
  return new Promise((resolve, reject) => {
    fs.writeFile('./dados.json', json, (err) => {
      if (err) {
        reject(err);
      }
      resolve(console.log('Carro cadastrado com sucesso!'));
    })
  })
}

//Funções para o cadastro de novos carros
function obterCarros() {
  return new Promise((resolve, reject) => {
    fs.readFile('./dados.json', 'utf-8', (err, data) => {
      if (err) {
        reject(err);
      }
      resolve(data);
    })
  });
}


//Função assíncrona para listar a tabela de dados do arquivo json
async function listarCarros() {
    var carros = await obterCarros();
    var dados = JSON.parse(carros).dados;
    console.table(dados);
}


//Função assíncrona para permitir a escolha entre as 3 opções
async function Escolha() {
  let opcao;
  do {
    console.log('Bem-vindo ao sistema de carros!');
    console.log('\n', '1. Listar Carros', '\n', '2. Cadastrar Carros', '\n', '3. Sair', '\n');
    opcao = prompt("Digite a opção desejada: ");
    switch (opcao) {
      case "1":
        await listarCarros();
        break;
      case "2":
        await cadastrarCarro();
        break;
      case "3":
        console.log('Saindo do sistema...');
        process.exit();
      default:
        console.log('Opção inválida, tente novamente!');
        break;
    }
  } while (opcao !== "3");
}

//Chamada da função Escolha
Escolha();