var pares = 0; // inicialização da contagem dos números pares
var impares = 0; // inicialização da contagem dos números ímpares

for (var i = 1; i <= 20; i++) {
  var quad = i * i; // checagem se o número é quadrado 
  console.log(quad);
  if (quad % 2 == 0) { // checagem se o número é par
    pares = pares + quad // soma dos números pares
  } else {
    impares =  impares + quad //soma dos números ímpares
  }
}

console.log("A soma de quadrados pares: ", pares);
console.log("A soma de quadrados ímpares: ", impares);