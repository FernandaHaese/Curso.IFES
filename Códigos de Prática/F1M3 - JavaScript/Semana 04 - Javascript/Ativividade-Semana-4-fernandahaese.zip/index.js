const prompt = require('prompt-sync')();

let alturas = []
// inicialização 

for (let i = 0; i < 10; i++) {                 
  a = parseFloat(prompt("Digite a altura: "));
  alturas.push(a);                             
} // entrada de dados

for (let i = 0; i < 10; i++) {                 
  let cont = 0;

  for (let j = 0; j < 10; j++) {               
    if (alturas[i] > alturas[j]) {             
      cont = cont + 1;                         
    }
  } // processamento de dados

  console.log("Aluno " + i + ": maior que " + cont + " aluno(s)");
} // saída de dados

