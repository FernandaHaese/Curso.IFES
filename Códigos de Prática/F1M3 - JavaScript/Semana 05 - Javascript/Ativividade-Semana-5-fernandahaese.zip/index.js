const prompt = require('prompt-sync')();
var array_canetas = [];

do {
  console.log("Sistema de Cadastro de Canetas");
  console.log("1 - Inserir Caneta");
  console.log("2 - Excluir Caneta");
  console.log("3 - Listar Canetas");
  console.log("0 - Sair");

  var opcao = prompt("Digite sua opção: ");

  if (opcao == 1) {
    console.log("\n\nInserindo Caneta...\n");
    let codigo = parseInt(prompt("Digite o código: "));
    let tipo = prompt("Digite o tipo: ");
    let cor = prompt("Digite a cor: ");
    let espessura = prompt("Digite a espessura: ");
    let material = prompt("Digite o material: ");

    // Neste trecho estamos declarando um objeto
    const caneta = {
      codigo: codigo,
      tipo: tipo,
      cor: cor,
      espessura: espessura,
      material: material
    }
    // Chamar a função inserir
    inserir_caneta(caneta);
  } else if (opcao == 2) {
    console.log("\n\nExcluindo Caneta...\n");
    let codigo = prompt("Digite o código da caneta: ");   
    // Chamar a função excluir
    excluir_caneta(codigo);
  } else if (opcao == 3) {
    console.log("\n\nListando Canetas...\n");
    // Chamar a função listar
    listar_canetas();
  } else {
    console.log("\n\nSaindo do programa...\n");
  }

  prompt("\nEnter para continuar...");
  console.clear();
} while (opcao != 0)


function inserir_caneta(caneta) {
  // Implementar corpo da função
  array_canetas.push(caneta);
}

function excluir_caneta(codigo) {
  // Implementar corpo da função
  for(i = 0;i < array_canetas.length; i++) {
    if (array_canetas[i].codigo == codigo) {
      array_canetas.splice(i, 1);
    }
  }
}

function listar_canetas() {
  // Implementar corpo da função
  for (i = 0; i < array_canetas.length; i++) {
    a = array_canetas[i]
    console.log(a.codigo, ",", a.tipo, ",", a.cor, ",", a.espessura, ",", a.material);
  }
  
}
