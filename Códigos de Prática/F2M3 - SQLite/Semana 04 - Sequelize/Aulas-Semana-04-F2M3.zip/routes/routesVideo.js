//Criando as constantes usadas
const express = require("express");
const ControllerVideo = require("../controllers/ControllerVideo");
const router = express.Router();
//Chamar a função de cadastro
router.get("/Cadastrar", ControllerVideo.cadastrarVideo);
router.post("/Cadastrar", ControllerVideo.VideoCreate);
//Chamar a listagem dos vídeos no db
router.get("/", ControllerVideo.listarVideos);
//Chamar a função de atualização
router.get("/update/:id_video", ControllerVideo.UpdateVideo);
router.post("/update", ControllerVideo.VideoUpdate);
//Chamar a função de deletar
router.post("/remover", ControllerVideo.removerVideo);
//Exportação do módulo
module.exports = router;