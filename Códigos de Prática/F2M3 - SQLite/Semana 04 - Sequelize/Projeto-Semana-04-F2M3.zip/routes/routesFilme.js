//Criando as constantes usadas
const express = require("express");
const ControllerFilme = require("../controllers/ControllerFilme");
const router = express.Router();
//Chamar a função de cadastro
router.get("/Cadastrar", ControllerFilme.cadastrarFilme);
router.post("/Cadastrar", ControllerFilme.FilmeCreate);
//Chamar a listagem dos filmes no db
router.get("/", ControllerFilme.listarFilmes);
//Chamar a função de atualização
router.get("/update/:id_filme", ControllerFilme.UpdateFilme);
router.post("/update", ControllerFilme.FilmeUpdate);
//Chamar a função de deletar
router.post("/remover", ControllerFilme.removerFilme);
//Exportação do módulo
module.exports = router;