//Criar nossa classe vídeo e nosso cadastrarFilme.
const Filme = require("../models/filme");
module.exports = class FilmeController {
static cadastrarFilme(req,res) {
res.render("filmes/Cadastrar");
}
//Criar a função create nosso C do CRUD.
static async FilmeCreate(req,res) {
const filme = {
titulo: req.body.titulo,
categoria: req.body.categoria,
genero: req.body.genero,
sinopse: req.body.sinopse
}
await Filme.create(filme);
res.send("Cadastro realizado com sucesso!");
res.redirect("/")
}
//Criar a função listar na nossa classe.
static async listarFilmes(req,res) {
const filme = await Filme.findAll({ raw:true })
res.render("filmes/listar", {filme});
}
//Realizar o update.
static async UpdateFilme(req,res) {
const id_filme = req.params.id_filme;
const filme = await Filme.findOne({where: {id_filme: id_filme}, raw : true})
res.render("filmes/update", {filme})
}
static async FilmeUpdate(req, res) {
const id_filme = req.body.id_filme
const filme = {
titulo: req.body.titulo,
categoria: req.body.categoria,
genero: req.body.genero,
sinopse: req.body.sinopse
}
await Filme.update(filme, { where: { id_filme:id_filme }})
res.redirect("/")
}
//Vamos criar a função delete.
static async removerFilme(req,res) {
const id_filme = req.body.id_filme;
await Filme.destroy({ where: { id_filme: id_filme }})
res.redirect("/")
}}