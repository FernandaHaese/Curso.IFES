//Declarar constantes
const express = require("express");
const session = require("express-session");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const path = require("path");
const app = express();
const porta = 443;

// Configuração do middleware de análise de corpo de solicitação
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//Configuração CSS
app.use("/static", express.static("assets"));

//Configuração da engine de visualização
app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");
app.set("views", path.join(__dirname, "./"));

//Configuração da sessão
app.use(
  session({
    secret: "1234567890",
    resave: true,
    saveUninitialized: true,
  })
);

//Usuários cadastrados
var login = "admin";
var senha = "1234";

//Rota principal
app.get("/", (req, res) => {
  if (req.session.login) {
    res.render("logado");
    console.log("Usuário logado: " + req.session.login);
  } else {
    res.render("home");
  }
});

//Rota de login
app.post("/", (req, res) => {
  if (req.body.password == senha && req.body.login == login) {
    req.session.login = login;
    res.render("logado");
    console.log("Usuário logado: " + req.session.login);
  } else {
    res.render("home");
  }
});

//Rota do email
app.get("/email", (req, res) => {
  res.render("email");
});

//Configurações de envio
app.post("/sendemail", (req, res) => {
  const { email, subject, message } = req.body;
  var transport = nodemailer.createTransport({
    host: "sandbox.smtp.mailtrap.io",
    port: 2525,
    auth: {
      user: "eacf0813819833",
      pass: "ef89138d0bb89d",
    },
  });
  const mensagem = {
    from: "sandbox.smtp.mailtrap.io",
    to: email,
    // email@example.com
    subject: subject,
    message: message,
  };
  transport.sendMail(mensagem, (error) => {
    if (error) {
      console.log(error);
      res.send("Erro ao enviar o e-mail!");
    } else {
      console.log("E-mail enviado com sucesso!");
      res.send("E-mail enviado com sucesso!");
    }
  });
});

//Listener do servidor
app.listen(porta, () => {
  console.log("Servidor rodando");
});