Olá!

Nesta atividade você vai colocar em prática o conteúdo abordado na semana.

ESTA ATIVIDADE SERÁ DESENVOLVIDA NO REPLIT E DEVERÁ SER POSTADA NESTA TAREFA EM ARQUIVO ZIP. ENVIE TAMBÉM O LINK DO REPLIT COMO COMENTÁRIO, CONFORME ORIENTAÇÕES ABAIXO:

Você deve criar uma API (Application Programming Interface - Interface de Programação de Aplicações) em Node que ofereça autenticação de usuários (acesso à API) e o serviço de envio de e-mail, com as seguintes funcionalidades:

Crie uma página principal (que será lida) em HTML (home.html) com título e subtítulo. Apresente a opção de informar usuário e senha.

Crie o serviço de autenticação de usuários (acesso à API). 

Crie uma página (que será lida) em HTML (logado.html) com título: "Você está logado!".

Após autenticado (abertura da página logado.html), crie um redirecionamento automático para a página e-mail.html.
Crie uma página (que será lida) em HTML (email.html) para envio de e-mail, com título: "Área de envio de e-mail". Crie um campo para inserir o e-mail e um botão com a função de enviar (enviar o e-mail).
Adicione CSS às páginas HTML, mude a cor de fundo e a cor da fonte, pelo menos. 
As configurações do envio do e-mail (https://mailtrap.io/) serão enviadas a você pelo Mediador.
O e-mail que você enviará será para ele, para as configurações da conta dele. 
Siga o caminho abaixo:

Assista aos vídeos da semana.

Leia, em paralelo, os materiais das aulas da semana.

Acesse o Replit.

Realize a codificação da atividade (Prática da semana 4).

Salve o código no seu computador.

Compacte o arquivo.

Envie o arquivo aqui.

Se a atividade não estiver sendo mostrada para você, entre em contato com o monitor ou professor mediador o quanto antes.

Valor: 20 pontos

Prazo final: 24/04/2023