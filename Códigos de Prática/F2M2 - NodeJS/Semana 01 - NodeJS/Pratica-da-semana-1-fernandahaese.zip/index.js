//Requisições aos módulos usados
const http = require('http');
const fs = require('fs');
const readline = require('readline');
//Definir a porta 443 para https
const porta = 443;

//Criar o servidor, ler o arquivo html 
const servidor = http.createServer((req, res) => {
  fs.readFile('pagina.html', (err, arquivo) => {
      res.writeHead(200, {'Content-type' : "text/html"})
      res.write(arquivo);
      res.end();
    });
})

//Criando o arquivo texto.txt
fs.appendFile('texto.txt', 'Frase criada pelo appendFile diretamente no txt', (err) => {
      if(err) throw err;
      console.log('Arquivo criado com sucesso.');
    });

//Leitura do arquivo texto.txt
async function readFileByLine(file) {
const fileStream = fs.createReadStream(file);
const rl = readline.createInterface({
input: fileStream,
crlfDelay: Infinity
});
for await (const line of rl) {
console.log(line);
}}
readFileByLine('texto.txt')

//Checagem de funcionamento padrão do servidor
servidor.listen(porta, () => {
    console.log('Servidor rodando')})