(function() {
  'use strict'

  var forms = document.querySelectorAll('.needs-validation')

  Array.prototype.slice.call(forms)
    .forEach(function(form) {
      form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
          form.classList.add('was-validated')
        } else {
          inserir()
          form.classList.remove('was-validated')
          form.reset()
        }
        event.preventDefault()
        event.stopPropagation()
      }, false)
    })
})()

$(function() {
    $('.custom4').maskMoney();
  })

function getLocalStorage() {
  return JSON.parse(localStorage.getItem('bd_moveis')) ?? [];
}

function setLocalStorage(bd_moveis) {
  localStorage.setItem('bd_moveis', JSON.stringify(bd_moveis));
}

function limparTabela() {
  var elemento = document.querySelector("#tabela>tbody");
  while (elemento.firstChild) {
    elemento.removeChild(elemento.firstChild);
  }
}

function atualizarTabela() { // Adaptação da função atualizarTabela (5 pontos)
  limparTabela();
  const bd_moveis = getLocalStorage();
  let index = 0;
  for (movel of bd_moveis) {
    const novaLinha = document.createElement('tr');
    novaLinha.innerHTML = `
        <th scope="row">${index}</th>
        <td>${movel.tipo}</td>
        <td>${movel.material}</td>
        <td>${movel.ambiente}</td>
        <td>${movel.marca}</td>
        <td>${movel.preco}</td>
        <td>${movel.codigo}</td>
        <td>
            <button type="button" class="btn btn-danger" id="${index}" onclick="excluir(${index})">Excluir</button>
        </td>
    `
document.querySelector('#tabela>tbody').appendChild(novaLinha)
    index++;
  }
}

function inserir() { // Adaptação da função inserir (10 pontos)
  const movel = {
    tipo: document.getElementById('tipo').value,
    material: document.getElementById('material').value,
    ambiente: document.getElementById('ambiente').value,
    marca: document.getElementById('marca').value,
    preco: document.getElementById('preco').value,
    codigo: document.getElementById('codigo').value
  };
  const bd_moveis = getLocalStorage();
  bd_moveis.push(movel);
  setLocalStorage(bd_moveis);
  atualizarTabela();
}

function excluir(index) { // Adaptação da função excluir (5 pontos)
  const bd_moveis = getLocalStorage();
  bd_moveis.splice(index, 1);
  setLocalStorage(bd_moveis);
  atualizarTabela();
}

function validarCodigo() { // Adaptação da função validar (10 pontos)
  const bd_moveis = getLocalStorage();
  for (movel of bd_moveis) {
    if (codigo.value == movel.codigo) {
      codigo.setCustomValidity("Este código já foi cadastrado!");
      feedbackCodigo.innerText = "Este código já foi cadastrado!";
      return false;
    } else {
      codigo.setCustomValidity("");
      feedbackCodigo.innerText = "Informe o código corretamente.";
    }
  }
  return true;
}

atualizarTabela();
// Seleção dos elementos e adição do listener para validação customizada (5 pontos)
const codigo = document.getElementById("codigo");
const feedbackCodigo = document.getElementById("feedbackCodigo");
codigo.addEventListener('input', validarCodigo);
