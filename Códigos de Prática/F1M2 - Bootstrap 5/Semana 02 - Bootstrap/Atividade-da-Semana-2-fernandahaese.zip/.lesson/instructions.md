# Atividade Prática da Semana 2  

Na atividade prática desta segunda semana do módulo 2, você deverá abrir os arquivos questao01.html até questao10.html e fazer o que é pedido no enunciado de cada questão. Não deixe de ver o vídeo de apresentação desta atividade no ambiente virtual de aprendizagem, pois ele contém muitos detalhes importantes sobre a realização da atividade.

Bons estudos!